﻿namespace Ethernet
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.richTextBox12 = new System.Windows.Forms.RichTextBox();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.state_button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.save_enrj_off_button = new System.Windows.Forms.Button();
            this.tx_on_button = new System.Windows.Forms.Button();
            this.save_enrj_on_button = new System.Windows.Forms.Button();
            this.modem_off_button = new System.Windows.Forms.Button();
            this.modem_on_button = new System.Windows.Forms.Button();
            this.gps_off_button = new System.Windows.Forms.Button();
            this.gps_on_button = new System.Windows.Forms.Button();
            this.tx_off_button = new System.Windows.Forms.Button();
            this.light_off_button = new System.Windows.Forms.Button();
            this.light_on_button = new System.Windows.Forms.Button();
            this.from_accum_off_button = new System.Windows.Forms.Button();
            this.from_accum_on_button = new System.Windows.Forms.Button();
            this.ext_control_off_button = new System.Windows.Forms.Button();
            this.ext_control_on_button = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.textBox24);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.textBox22);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBox21);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBox20);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(11, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(245, 230);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Настройки соединения";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox2.ForeColor = System.Drawing.Color.ForestGreen;
            this.checkBox2.Location = new System.Drawing.Point(82, 193);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(142, 29);
            this.checkBox2.TabIndex = 17;
            this.checkBox2.Text = "Соединить";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(11, 79);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(109, 20);
            this.label13.TabIndex = 14;
            this.label13.Text = "Destination IP";
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox24.Location = new System.Drawing.Point(124, 76);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 25);
            this.textBox24.TabIndex = 13;
            this.textBox24.Text = "192.168.0.65";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(11, 123);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 20);
            this.label10.TabIndex = 11;
            this.label10.Text = "Device name";
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox22.Location = new System.Drawing.Point(124, 120);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 25);
            this.textBox22.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(11, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 20);
            this.label9.TabIndex = 9;
            this.label9.Text = "Source IP";
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox21.Location = new System.Drawing.Point(124, 33);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 25);
            this.textBox21.TabIndex = 8;
            this.textBox21.Text = "192.168.0.50";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(11, 165);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Port";
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox20.Location = new System.Drawing.Point(124, 162);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 25);
            this.textBox20.TabIndex = 6;
            this.textBox20.Text = "4001";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox3.Controls.Add(this.textBox14);
            this.groupBox3.Controls.Add(this.textBox13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.textBox12);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.richTextBox12);
            this.groupBox3.Controls.Add(this.richTextBox11);
            this.groupBox3.Controls.Add(this.richTextBox10);
            this.groupBox3.Controls.Add(this.richTextBox9);
            this.groupBox3.Controls.Add(this.richTextBox8);
            this.groupBox3.Controls.Add(this.richTextBox7);
            this.groupBox3.Controls.Add(this.richTextBox6);
            this.groupBox3.Controls.Add(this.richTextBox5);
            this.groupBox3.Controls.Add(this.richTextBox4);
            this.groupBox3.Controls.Add(this.richTextBox3);
            this.groupBox3.Controls.Add(this.richTextBox2);
            this.groupBox3.Controls.Add(this.richTextBox1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(11, 246);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(958, 316);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Прием";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox14.Location = new System.Drawing.Point(15, 158);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(600, 25);
            this.textBox14.TabIndex = 57;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox13.Location = new System.Drawing.Point(419, 215);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(55, 25);
            this.textBox13.TabIndex = 56;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(415, 192);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 20);
            this.label14.TabIndex = 55;
            this.label14.Text = "Температура, °C";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox12.Location = new System.Drawing.Point(707, 274);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(55, 25);
            this.textBox12.TabIndex = 54;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(683, 251);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(124, 20);
            this.label12.TabIndex = 53;
            this.label12.Text = "Ток заряда, мА";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox11.Location = new System.Drawing.Point(707, 215);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(55, 25);
            this.textBox11.TabIndex = 52;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(683, 192);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 20);
            this.label11.TabIndex = 51;
            this.label11.Text = "Заряд АКБ, %";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9.Location = new System.Drawing.Point(707, 55);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(55, 25);
            this.textBox9.TabIndex = 50;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(683, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(170, 20);
            this.label7.TabIndex = 49;
            this.label7.Text = "Напряжение АКБ, мВ";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox7.Location = new System.Drawing.Point(15, 277);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(55, 25);
            this.textBox7.TabIndex = 48;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(11, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(298, 20);
            this.label6.TabIndex = 47;
            this.label6.Text = "Потребляемый ток светильником, мА";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox5.Location = new System.Drawing.Point(217, 215);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(55, 25);
            this.textBox5.TabIndex = 46;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(213, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 20);
            this.label5.TabIndex = 45;
            this.label5.Text = "Потребляемый ток, мА";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3.Location = new System.Drawing.Point(15, 215);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(55, 25);
            this.textBox3.TabIndex = 44;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(11, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 20);
            this.label4.TabIndex = 43;
            this.label4.Text = "Напряжение сети, мВ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(683, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 42;
            this.label3.Text = "4";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(683, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 20);
            this.label2.TabIndex = 41;
            this.label2.Text = "1";
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox10.Location = new System.Drawing.Point(768, 149);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(55, 25);
            this.textBox10.TabIndex = 40;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox8.Location = new System.Drawing.Point(707, 149);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(55, 25);
            this.textBox8.TabIndex = 38;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox6.Location = new System.Drawing.Point(829, 118);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(55, 25);
            this.textBox6.TabIndex = 36;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4.Location = new System.Drawing.Point(768, 118);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(55, 25);
            this.textBox4.TabIndex = 34;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(829, 149);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(55, 25);
            this.textBox2.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(683, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Напряжение ячеек, мВ";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(707, 118);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(55, 25);
            this.textBox1.TabIndex = 31;
            // 
            // richTextBox12
            // 
            this.richTextBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox12.Location = new System.Drawing.Point(520, 95);
            this.richTextBox12.Name = "richTextBox12";
            this.richTextBox12.ReadOnly = true;
            this.richTextBox12.Size = new System.Drawing.Size(95, 57);
            this.richTextBox12.TabIndex = 30;
            this.richTextBox12.Text = "БАЛАНС АКБ";
            // 
            // richTextBox11
            // 
            this.richTextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox11.Location = new System.Drawing.Point(419, 95);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.ReadOnly = true;
            this.richTextBox11.Size = new System.Drawing.Size(95, 57);
            this.richTextBox11.TabIndex = 29;
            this.richTextBox11.Text = "ЗАРЯД АКБ";
            // 
            // richTextBox10
            // 
            this.richTextBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox10.Location = new System.Drawing.Point(318, 95);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.ReadOnly = true;
            this.richTextBox10.Size = new System.Drawing.Size(95, 57);
            this.richTextBox10.TabIndex = 28;
            this.richTextBox10.Text = "ДЗ ГБРЭ";
            // 
            // richTextBox9
            // 
            this.richTextBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox9.Location = new System.Drawing.Point(217, 95);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.ReadOnly = true;
            this.richTextBox9.Size = new System.Drawing.Size(95, 57);
            this.richTextBox9.TabIndex = 27;
            this.richTextBox9.Text = "ПИТАНИЕ ОТ АКБ";
            // 
            // richTextBox8
            // 
            this.richTextBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox8.Location = new System.Drawing.Point(116, 95);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.ReadOnly = true;
            this.richTextBox8.Size = new System.Drawing.Size(95, 57);
            this.richTextBox8.TabIndex = 26;
            this.richTextBox8.Text = "Э/СБЕР";
            // 
            // richTextBox7
            // 
            this.richTextBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox7.Location = new System.Drawing.Point(15, 95);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.ReadOnly = true;
            this.richTextBox7.Size = new System.Drawing.Size(95, 57);
            this.richTextBox7.TabIndex = 25;
            this.richTextBox7.Text = "GPS";
            // 
            // richTextBox6
            // 
            this.richTextBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox6.Location = new System.Drawing.Point(520, 32);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.ReadOnly = true;
            this.richTextBox6.Size = new System.Drawing.Size(95, 57);
            this.richTextBox6.TabIndex = 24;
            this.richTextBox6.Text = "ТХ МОДЕМА";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox5.Location = new System.Drawing.Point(419, 32);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.ReadOnly = true;
            this.richTextBox5.Size = new System.Drawing.Size(95, 57);
            this.richTextBox5.TabIndex = 23;
            this.richTextBox5.Text = "СВЕТ";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox4.Location = new System.Drawing.Point(318, 32);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.Size = new System.Drawing.Size(95, 57);
            this.richTextBox4.TabIndex = 22;
            this.richTextBox4.Text = "ВНУТР УПР-Е";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox3.Location = new System.Drawing.Point(217, 32);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.Size = new System.Drawing.Size(95, 57);
            this.richTextBox3.TabIndex = 21;
            this.richTextBox3.Text = "ДВВ";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox2.Location = new System.Drawing.Point(116, 32);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(95, 57);
            this.richTextBox2.TabIndex = 20;
            this.richTextBox2.Text = "ДЗ АМ";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox1.Location = new System.Drawing.Point(15, 32);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(95, 57);
            this.richTextBox1.TabIndex = 19;
            this.richTextBox1.Text = "ВКЛ МОДЕМ";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // state_button
            // 
            this.state_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.state_button.Location = new System.Drawing.Point(22, 33);
            this.state_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.state_button.Name = "state_button";
            this.state_button.Size = new System.Drawing.Size(95, 58);
            this.state_button.TabIndex = 0;
            this.state_button.Text = "СТАТУС";
            this.state_button.UseVisualStyleBackColor = true;
            this.state_button.Click += new System.EventHandler(this.state_button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.save_enrj_off_button);
            this.groupBox2.Controls.Add(this.tx_on_button);
            this.groupBox2.Controls.Add(this.save_enrj_on_button);
            this.groupBox2.Controls.Add(this.modem_off_button);
            this.groupBox2.Controls.Add(this.modem_on_button);
            this.groupBox2.Controls.Add(this.gps_off_button);
            this.groupBox2.Controls.Add(this.gps_on_button);
            this.groupBox2.Controls.Add(this.tx_off_button);
            this.groupBox2.Controls.Add(this.light_off_button);
            this.groupBox2.Controls.Add(this.light_on_button);
            this.groupBox2.Controls.Add(this.from_accum_off_button);
            this.groupBox2.Controls.Add(this.from_accum_on_button);
            this.groupBox2.Controls.Add(this.ext_control_off_button);
            this.groupBox2.Controls.Add(this.ext_control_on_button);
            this.groupBox2.Controls.Add(this.state_button);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(261, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(708, 230);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Запрос";
            // 
            // save_enrj_off_button
            // 
            this.save_enrj_off_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.save_enrj_off_button.Location = new System.Drawing.Point(494, 158);
            this.save_enrj_off_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.save_enrj_off_button.Name = "save_enrj_off_button";
            this.save_enrj_off_button.Size = new System.Drawing.Size(150, 58);
            this.save_enrj_off_button.TabIndex = 15;
            this.save_enrj_off_button.Text = "ВЫКЛ ЭНЕРГОСБЕР";
            this.save_enrj_off_button.UseVisualStyleBackColor = true;
            this.save_enrj_off_button.Click += new System.EventHandler(this.save_enrj_off_button_Click);
            // 
            // tx_on_button
            // 
            this.tx_on_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tx_on_button.Location = new System.Drawing.Point(351, 96);
            this.tx_on_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tx_on_button.Name = "tx_on_button";
            this.tx_on_button.Size = new System.Drawing.Size(138, 58);
            this.tx_on_button.TabIndex = 14;
            this.tx_on_button.Text = "ВКЛ TX МОДЕМА";
            this.tx_on_button.UseVisualStyleBackColor = true;
            this.tx_on_button.Click += new System.EventHandler(this.tx_on_button_Click);
            // 
            // save_enrj_on_button
            // 
            this.save_enrj_on_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.save_enrj_on_button.Location = new System.Drawing.Point(351, 158);
            this.save_enrj_on_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.save_enrj_on_button.Name = "save_enrj_on_button";
            this.save_enrj_on_button.Size = new System.Drawing.Size(138, 58);
            this.save_enrj_on_button.TabIndex = 12;
            this.save_enrj_on_button.Text = "ВКЛ ЭНЕРГОСБЕР";
            this.save_enrj_on_button.UseVisualStyleBackColor = true;
            this.save_enrj_on_button.Click += new System.EventHandler(this.save_enrj_on_button_Click);
            // 
            // modem_off_button
            // 
            this.modem_off_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.modem_off_button.Location = new System.Drawing.Point(22, 158);
            this.modem_off_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.modem_off_button.Name = "modem_off_button";
            this.modem_off_button.Size = new System.Drawing.Size(95, 58);
            this.modem_off_button.TabIndex = 11;
            this.modem_off_button.Text = "ВЫКЛ МОДЕМ";
            this.modem_off_button.UseVisualStyleBackColor = true;
            this.modem_off_button.Click += new System.EventHandler(this.modem_off_button_Click);
            // 
            // modem_on_button
            // 
            this.modem_on_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.modem_on_button.Location = new System.Drawing.Point(22, 96);
            this.modem_on_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.modem_on_button.Name = "modem_on_button";
            this.modem_on_button.Size = new System.Drawing.Size(95, 58);
            this.modem_on_button.TabIndex = 10;
            this.modem_on_button.Text = "ВКЛ МОДЕМ";
            this.modem_on_button.UseVisualStyleBackColor = true;
            this.modem_on_button.Click += new System.EventHandler(this.modem_on_button_Click);
            // 
            // gps_off_button
            // 
            this.gps_off_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gps_off_button.Location = new System.Drawing.Point(231, 158);
            this.gps_off_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gps_off_button.Name = "gps_off_button";
            this.gps_off_button.Size = new System.Drawing.Size(115, 58);
            this.gps_off_button.TabIndex = 9;
            this.gps_off_button.Text = "ВЫКЛ GPS";
            this.gps_off_button.UseVisualStyleBackColor = true;
            this.gps_off_button.Click += new System.EventHandler(this.gps_off_button_Click);
            // 
            // gps_on_button
            // 
            this.gps_on_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gps_on_button.Location = new System.Drawing.Point(123, 158);
            this.gps_on_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gps_on_button.Name = "gps_on_button";
            this.gps_on_button.Size = new System.Drawing.Size(103, 58);
            this.gps_on_button.TabIndex = 8;
            this.gps_on_button.Text = "ВКЛ GPS";
            this.gps_on_button.UseVisualStyleBackColor = true;
            this.gps_on_button.Click += new System.EventHandler(this.gps_on_button_Click);
            // 
            // tx_off_button
            // 
            this.tx_off_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tx_off_button.Location = new System.Drawing.Point(494, 96);
            this.tx_off_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tx_off_button.Name = "tx_off_button";
            this.tx_off_button.Size = new System.Drawing.Size(150, 58);
            this.tx_off_button.TabIndex = 7;
            this.tx_off_button.Text = "ВЫКЛ TX МОДЕМА";
            this.tx_off_button.UseVisualStyleBackColor = true;
            this.tx_off_button.Click += new System.EventHandler(this.tx_off_button_Click);
            // 
            // light_off_button
            // 
            this.light_off_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.light_off_button.Location = new System.Drawing.Point(231, 96);
            this.light_off_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.light_off_button.Name = "light_off_button";
            this.light_off_button.Size = new System.Drawing.Size(115, 58);
            this.light_off_button.TabIndex = 6;
            this.light_off_button.Text = "ВЫКЛ СВЕТ";
            this.light_off_button.UseVisualStyleBackColor = true;
            this.light_off_button.Click += new System.EventHandler(this.light_off_button_Click);
            // 
            // light_on_button
            // 
            this.light_on_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.light_on_button.Location = new System.Drawing.Point(123, 96);
            this.light_on_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.light_on_button.Name = "light_on_button";
            this.light_on_button.Size = new System.Drawing.Size(103, 58);
            this.light_on_button.TabIndex = 5;
            this.light_on_button.Text = "ВКЛ СВЕТ";
            this.light_on_button.UseVisualStyleBackColor = true;
            this.light_on_button.Click += new System.EventHandler(this.light_on_button_Click);
            // 
            // from_accum_off_button
            // 
            this.from_accum_off_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.from_accum_off_button.Location = new System.Drawing.Point(494, 34);
            this.from_accum_off_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.from_accum_off_button.Name = "from_accum_off_button";
            this.from_accum_off_button.Size = new System.Drawing.Size(150, 58);
            this.from_accum_off_button.TabIndex = 4;
            this.from_accum_off_button.Text = "ВЫКЛ ПИТАНИЕ ОТ АКБ";
            this.from_accum_off_button.UseVisualStyleBackColor = true;
            this.from_accum_off_button.Click += new System.EventHandler(this.from_accum_off_button_Click);
            // 
            // from_accum_on_button
            // 
            this.from_accum_on_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.from_accum_on_button.Location = new System.Drawing.Point(351, 34);
            this.from_accum_on_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.from_accum_on_button.Name = "from_accum_on_button";
            this.from_accum_on_button.Size = new System.Drawing.Size(138, 58);
            this.from_accum_on_button.TabIndex = 3;
            this.from_accum_on_button.Text = "ВКЛ ПИТАНИЕ ОТ АКБ";
            this.from_accum_on_button.UseVisualStyleBackColor = true;
            this.from_accum_on_button.Click += new System.EventHandler(this.from_accum_on_button_Click);
            // 
            // ext_control_off_button
            // 
            this.ext_control_off_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ext_control_off_button.Location = new System.Drawing.Point(231, 34);
            this.ext_control_off_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ext_control_off_button.Name = "ext_control_off_button";
            this.ext_control_off_button.Size = new System.Drawing.Size(115, 58);
            this.ext_control_off_button.TabIndex = 2;
            this.ext_control_off_button.Text = "ВЫКЛ ВНЕШ УПР АМ";
            this.ext_control_off_button.UseVisualStyleBackColor = true;
            this.ext_control_off_button.Click += new System.EventHandler(this.ext_control_off_button_Click);
            // 
            // ext_control_on_button
            // 
            this.ext_control_on_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ext_control_on_button.Location = new System.Drawing.Point(123, 33);
            this.ext_control_on_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ext_control_on_button.Name = "ext_control_on_button";
            this.ext_control_on_button.Size = new System.Drawing.Size(103, 58);
            this.ext_control_on_button.TabIndex = 1;
            this.ext_control_on_button.Text = "ВКЛ ВНЕШ УПР АМ";
            this.ext_control_on_button.UseVisualStyleBackColor = true;
            this.ext_control_on_button.Click += new System.EventHandler(this.ext_control_on_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(981, 571);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button state_button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button save_enrj_off_button;
        private System.Windows.Forms.Button tx_on_button;
        private System.Windows.Forms.Button save_enrj_on_button;
        private System.Windows.Forms.Button modem_off_button;
        private System.Windows.Forms.Button modem_on_button;
        private System.Windows.Forms.Button gps_off_button;
        private System.Windows.Forms.Button gps_on_button;
        private System.Windows.Forms.Button tx_off_button;
        private System.Windows.Forms.Button light_off_button;
        private System.Windows.Forms.Button light_on_button;
        private System.Windows.Forms.Button from_accum_off_button;
        private System.Windows.Forms.Button from_accum_on_button;
        private System.Windows.Forms.Button ext_control_off_button;
        private System.Windows.Forms.Button ext_control_on_button;
        private System.Windows.Forms.RichTextBox richTextBox12;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox14;
    }
}

