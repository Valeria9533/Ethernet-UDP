﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Data.SqlTypes;

// CMD 0-F
// DATA data_string

namespace Ethernet
{
    public partial class Form1 : Form
    {
        UdpClient udpClient = new UdpClient(4001); // port

        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            IPHostEntry _host = Dns.GetHostEntry(Dns.GetHostName());
            try
            {
                textBox21.Text = _host.AddressList[1].ToString(); // pc ip
                textBox22.Text = _host.HostName.ToString();
            }
            catch (Exception)
            {
                textBox21.Text = "";
                textBox22.Text = _host.HostName.ToString();
            }
        }

        /* Run and stop connection */
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                Thread thdUDPServer = new Thread(new ThreadStart(serverThread));
                thdUDPServer.Start();
            }
            else if (!checkBox2.Checked) {
                udpClient.Close();
            }
        }

        public void serverThread()
        {
            while (true) {
                try
                {
                    IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Parse(textBox24.Text), 4001); // stm32 ip
                    udpClient.Connect(RemoteIpEndPoint);
                    // чтение по 1 байту
                    byte[] inbyte = new byte[512];               
                    inbyte = udpClient.Receive(ref RemoteIpEndPoint);
                    string instring = Encoding.ASCII.GetString(inbyte);
                                                                     
                    Invoke(new MethodInvoker(delegate () {
                        textBox14.Text = instring; // received data
                        // DATA 1
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x01) == 0x01)
                            richTextBox1.BackColor = Color.LimeGreen;
                        else richTextBox1.BackColor = SystemColors.Control;
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x02) == 0x02)
                            richTextBox2.BackColor = Color.LightCoral;
                        else richTextBox2.BackColor = Color.LimeGreen; 
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x04) == 0x04)
                            richTextBox3.BackColor = Color.LightCoral;
                        else richTextBox3.BackColor = Color.LimeGreen;
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x08) == 0x08)
                            richTextBox4.Text = "ВНЕШ УПР-Е"; 
                        else richTextBox4.Text = "ВНУТР УПР-Е";
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x10) == 0x10)
                            richTextBox5.BackColor = Color.LimeGreen;
                        else richTextBox5.BackColor = SystemColors.Control;
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x20) == 0x20)
                            richTextBox6.BackColor = Color.LimeGreen;
                        else richTextBox6.BackColor = SystemColors.Control;
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x40) == 0x40)
                            richTextBox7.BackColor = Color.LimeGreen;
                        else richTextBox7.BackColor = SystemColors.Control;
                        if ((HEX_To_ASCII(inbyte[8], inbyte[9]) & 0x80) == 0x80)
                            richTextBox8.BackColor = Color.LimeGreen;
                        else richTextBox8.BackColor = SystemColors.Control;
                        // DATA 2
                        if ((HEX_To_ASCII(inbyte[11], inbyte[12]) & 0x01) == 0x01)
                            richTextBox9.BackColor = Color.LimeGreen; 
                        else richTextBox9.BackColor = SystemColors.Control;
                        if ((HEX_To_ASCII(inbyte[11], inbyte[12]) & 0x02) == 0x02)
                            richTextBox9.BackColor = Color.LightCoral;
                        else richTextBox9.BackColor = SystemColors.Control;
                        if ((HEX_To_ASCII(inbyte[11], inbyte[12]) & 0x04) == 0x04)
                            richTextBox10.BackColor = Color.LightCoral;
                        else richTextBox10.BackColor = Color.LimeGreen;
                        if ((HEX_To_ASCII(inbyte[11], inbyte[12]) & 0x08) == 0x08)
                            richTextBox11.BackColor = Color.LimeGreen;
                        else richTextBox11.BackColor = SystemColors.Control;
                        if ((HEX_To_ASCII(inbyte[11], inbyte[12]) & 0x10) == 0x10)
                            richTextBox12.BackColor = Color.LimeGreen;
                        else richTextBox12.BackColor = SystemColors.Control;
                        // DATA 3
                        textBox3.Text = Convert.ToString((HEX_To_ASCII(inbyte[14], inbyte[15]) << 8) + HEX_To_ASCII(inbyte[16], inbyte[17]));
                        // DATA 4
                        textBox5.Text = Convert.ToString((HEX_To_ASCII(inbyte[19], inbyte[20]) << 8) + HEX_To_ASCII(inbyte[21], inbyte[22]));
                        // DATA 5
                        textBox7.Text = Convert.ToString((HEX_To_ASCII(inbyte[24], inbyte[25]) << 8) + HEX_To_ASCII(inbyte[26], inbyte[27]));
                        // DATA 6
                        textBox11.Text = Convert.ToString(HEX_To_ASCII(inbyte[29], inbyte[30]));
                        // DATA 7 - DATA 12
                        textBox1.Text = Convert.ToString(HEX_To_ASCII(inbyte[32], inbyte[33]));
                        textBox4.Text = Convert.ToString(HEX_To_ASCII(inbyte[35], inbyte[36]));
                        textBox6.Text = Convert.ToString(HEX_To_ASCII(inbyte[38], inbyte[39]));
                        textBox8.Text = Convert.ToString(HEX_To_ASCII(inbyte[41], inbyte[42]));
                        textBox10.Text = Convert.ToString(HEX_To_ASCII(inbyte[44], inbyte[45]));
                        textBox2.Text = Convert.ToString(HEX_To_ASCII(inbyte[47], inbyte[48]));
                        // DATA 13
                        textBox9.Text = Convert.ToString((HEX_To_ASCII(inbyte[50], inbyte[51]) << 8) + HEX_To_ASCII(inbyte[52], inbyte[53]));
                        // DATA 14
                        textBox12.Text = Convert.ToString((HEX_To_ASCII(inbyte[55], inbyte[56]) << 8) + HEX_To_ASCII(inbyte[57], inbyte[58]));
                        // DATA 15
                        textBox13.Text = Convert.ToString(HEX_To_ASCII(inbyte[60], inbyte[61]));
                    }));                                  
                }
                catch { }
            }
        }
               
        /* Checksum */
        private byte checkSum(char[] str, int str_size)
        {
            byte sum = 0; 
            int i;
            for (i = 0; i < str_size; i++)
            {
                sum ^= (byte)str[i];
            }
            return sum;
        }

        /* Send */
        private void state_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,0";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            try { udpClient.Send(state, state.Length); }
            catch { }
        }

        private void ext_control_on_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,2";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void ext_control_off_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,3";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void from_accum_on_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,4";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void from_accum_off_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,5";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void light_on_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,6";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void light_off_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,7";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void gps_off_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,B";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void gps_on_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,A";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void tx_on_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,8";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void tx_off_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,9";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void modem_on_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,C";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void modem_off_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,D";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void save_enrj_on_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,E";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void save_enrj_off_button_Click(object sender, EventArgs e)
        {
            string str = "CMD,F";
            byte[] cmd = Encoding.ASCII.GetBytes(str);
            byte[] state = new byte[cmd.Length + 6];

            byte checksum = checkSum(str.ToCharArray(), str.Length);
            string checksumAscii = checksum.ToString("X2");
            byte[] checksumBytes = Encoding.ASCII.GetBytes(checksumAscii);

            state[0] = (byte)'$';
            for (byte i = 1; i <= cmd.Length; i++) state[i] = cmd[i - 1];
            state[6] = (byte)'*';
            state[7] = checksumBytes[0];
            state[8] = checksumBytes[1];
            state[9] = 0x0D;
            state[10] = 0x0A;
            udpClient.Send(state, state.Length);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            state_button.PerformClick();
        }

        private byte HEX_To_ASCII(int A, int B)
        {
            int C, D;

            if ((A >= 0x30) && (A <= 0x39)) D = A - 0x30;
            else D = A - 0x37;
            if ((B >= 0x30) && (B <= 0x39)) C = B - 0x30;
            else C = B - 0x37;
            C += (D << 4);

            return ((byte)C);
        }
    }
}
